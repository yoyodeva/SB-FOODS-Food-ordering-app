// JavaScript for adding items to the cart and calculating the total
const cartItems = [];
const menuItems = document.querySelectorAll('.menu-item');
const cartContainer = document.getElementById('cart-items');
const totalAmount = document.getElementById('total-amount');

menuItems.forEach((menuItem, index) => {
    menuItem.querySelector('.add-to-cart').addEventListener('click', () => {
        const itemName = menuItem.querySelector('h3').textContent;
        const itemPrice = parseFloat(menuItem.querySelector('p').textContent.replace('$', ''));

        // Add item to the cart array
        cartItems.push({ name: itemName, price: itemPrice });

        // Update cart display
        updateCartDisplay();
    });
});

function updateCartDisplay() {
    cartContainer.innerHTML = '';  // Clear previous items

    let total = 0;
    cartItems.forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.textContent = `${item.name} - $${item.price.toFixed(2)}`;
        cartContainer.appendChild(cartItem);

        total += item.price;
    });

    totalAmount.textContent = total.toFixed(2);
}

// Handle checkout button (currently does nothing)
document.getElementById('checkout-btn').addEventListener('click', () => {
    alert('Proceeding to checkout...');
});
